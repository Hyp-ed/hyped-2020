#!/usr/bin/env python
import sys

from lit.main import main

if __name__=='__main__':
    main()
